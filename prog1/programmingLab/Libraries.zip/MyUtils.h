#pragma once
Color4f RgbToColor4f(float r, float g, float b, float a = 255);
